import { DatabaseService } from "../utils/database"
import type { Rating } from "../models/interfaces"
import { v4 as uuidv4 } from "uuid"

export class RatingService {
  private db = DatabaseService.getInstance()

  public getAllRatings(): Rating[] {
    return this.db.getAll<Rating>("ratings")
  }

  public getRatingById(id: string): Rating | undefined {
    return this.db.getById<Rating>("ratings", id)
  }

  public getRatingsByRecipe(recipeId: string): Rating[] {
    return this.db.getAll<Rating>("ratings").filter((r) => r.recipeId === recipeId)
  }

  public createRating(ratingData: Omit<Rating, "id">): Rating {
    // Проверка дали рецептата съществува
    const recipe = this.db.getById("recipes", ratingData.recipeId)
    if (!recipe) {
      throw new Error(`Рецепта с ID ${ratingData.recipeId} не съществува`)
    }

    const rating: Rating = {
      id: uuidv4(),
      ...ratingData,
    }

    return this.db.create("ratings", rating)
  }

  public updateRating(id: string, updates: Partial<Rating>): Rating {
    if (updates.recipeId) {
      const recipe = this.db.getById("recipes", updates.recipeId)
      if (!recipe) {
        throw new Error(`Рецепта с ID ${updates.recipeId} не съществува`)
      }
    }

    return this.db.update("ratings", id, updates)
  }

  public deleteRating(id: string): boolean {
    return this.db.delete("ratings", id)
  }
}
