import { DatabaseService } from "../utils/database"
import type { Ingredient } from "../models/interfaces"
import { v4 as uuidv4 } from "uuid"

export class IngredientService {
  private db = DatabaseService.getInstance()

  public getAllIngredients(): Ingredient[] {
    return this.db.getAll<Ingredient>("ingredients")
  }

  public getIngredientById(id: string): Ingredient | undefined {
    return this.db.getById<Ingredient>("ingredients", id)
  }

  public createIngredient(ingredientData: Omit<Ingredient, "id">): Ingredient {
    const ingredient: Ingredient = {
      id: uuidv4(),
      ...ingredientData,
    }

    return this.db.create("ingredients", ingredient)
  }

  public updateIngredient(id: string, updates: Partial<Ingredient>): Ingredient {
    return this.db.update("ingredients", id, updates)
  }

  public deleteIngredient(id: string): boolean {
    return this.db.delete("ingredients", id)
  }
}
