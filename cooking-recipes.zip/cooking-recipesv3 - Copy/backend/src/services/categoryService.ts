import { DatabaseService } from "../utils/database"
import type { Category } from "../models/interfaces"
import { v4 as uuidv4 } from "uuid"

export class CategoryService {
  private db = DatabaseService.getInstance()

  public getAllCategories(): Category[] {
    return this.db.getAll<Category>("categories")
  }

  public getCategoryById(id: string): Category | undefined {
    return this.db.getById<Category>("categories", id)
  }

  public createCategory(categoryData: Omit<Category, "id">): Category {
    const category: Category = {
      id: uuidv4(),
      ...categoryData,
    }

    return this.db.create("categories", category)
  }

  public updateCategory(id: string, updates: Partial<Category>): Category {
    return this.db.update("categories", id, updates)
  }

  public deleteCategory(id: string): boolean {
    return this.db.delete("categories", id)
  }
}
