import { DatabaseService } from "../utils/database"
import type { Chef } from "../models/interfaces"
import { v4 as uuidv4 } from "uuid"

export class ChefService {
  private db = DatabaseService.getInstance()

  public getAllChefs(): Chef[] {
    return this.db.getAll<Chef>("chefs")
  }

  public getChefById(id: string): Chef | undefined {
    return this.db.getById<Chef>("chefs", id)
  }

  public createChef(chefData: Omit<Chef, "id">): Chef {
    const chef: Chef = {
      id: uuidv4(),
      ...chefData,
    }

    return this.db.create("chefs", chef)
  }

  public updateChef(id: string, updates: Partial<Chef>): Chef {
    return this.db.update("chefs", id, updates)
  }

  public deleteChef(id: string): boolean {
    return this.db.delete("chefs", id)
  }
}
