import { DatabaseService } from "../utils/database"
import type { Recipe } from "../models/interfaces"
import { v4 as uuidv4 } from "uuid"

export class RecipeService {
  private db = DatabaseService.getInstance()

  public getAllRecipes(): Recipe[] {
    return this.db.getAll<Recipe>("recipes")
  }

  public getRecipeById(id: string): Recipe | undefined {
    return this.db.getById<Recipe>("recipes", id)
  }

  public createRecipe(recipeData: Omit<Recipe, "id">): Recipe {
    const category = this.db.getById("categories", recipeData.categoryId)
    const chef = this.db.getById("chefs", recipeData.chefId)

    if (!category) {
      throw new Error(`Категория с ID ${recipeData.categoryId} не съществува`)
    }
    if (!chef) {
      throw new Error(`Готвач с ID ${recipeData.chefId} не съществува`)
    }

    // Проверка дали всички съставки съществуват
    for (const ingredient of recipeData.ingredients) {
      const ingredientExists = this.db.getById("ingredients", ingredient.ingredientId)
      if (!ingredientExists) {
        throw new Error(`Съставка с ID ${ingredient.ingredientId} не съществува`)
      }
    }

    const recipe: Recipe = {
      id: uuidv4(),
      ...recipeData,
    }

    return this.db.create("recipes", recipe)
  }

  public updateRecipe(id: string, updates: Partial<Recipe>): Recipe {
    if (updates.categoryId) {
      const category = this.db.getById("categories", updates.categoryId)
      if (!category) {
        throw new Error(`Категория с ID ${updates.categoryId} не съществува`)
      }
    }
    if (updates.chefId) {
      const chef = this.db.getById("chefs", updates.chefId)
      if (!chef) {
        throw new Error(`Готвач с ID ${updates.chefId} не съществува`)
      }
    }

    if (updates.ingredients) {
      for (const ingredient of updates.ingredients) {
        const ingredientExists = this.db.getById("ingredients", ingredient.ingredientId)
        if (!ingredientExists) {
          throw new Error(`Съставка с ID ${ingredient.ingredientId} не съществува`)
        }
      }
    }

    return this.db.update("recipes", id, updates)
  }

  public deleteRecipe(id: string): boolean {
    return this.db.delete("recipes", id)
  }
}
