import fs from "fs"
import path from "path"
import type { Recipe, Ingredient, Category, Chef, Rating } from "../models/interfaces"

interface Database {
  recipes: Recipe[]
  ingredients: Ingredient[]
  categories: Category[]
  chefs: Chef[]
  ratings: Rating[]
}

const DB_PATH = path.join(__dirname, "../../data/db.json")

const initDB = (): Database => {
  return {
    recipes: [
      {
        id: "1",
        name: "Шопска салата",
        ingredients: [
          { ingredientId: "1", quantity: 3, unit: "бр." },
          { ingredientId: "2", quantity: 2, unit: "бр." },
          { ingredientId: "3", quantity: 1, unit: "бр." },
          { ingredientId: "4", quantity: 200, unit: "гр." },
          { ingredientId: "5", quantity: 3, unit: "с.л." },
        ],
        cookingTime: 15,
        categoryId: "1",
        chefId: "1",
        rating: 5,
        description: "Традиционна българска салата с домати, краставици, лук и сирене. Перфектна за лятото!",
      },
      {
        id: "2",
        name: "Мусака",
        ingredients: [
          { ingredientId: "9", quantity: 1, unit: "кг" },
          { ingredientId: "10", quantity: 500, unit: "гр." },
          { ingredientId: "3", quantity: 2, unit: "бр." },
          { ingredientId: "12", quantity: 3, unit: "бр." },
          { ingredientId: "13", quantity: 200, unit: "мл" },
          { ingredientId: "8", quantity: 50, unit: "гр." },
          { ingredientId: "7", quantity: 1, unit: "ч.л." },
        ],
        cookingTime: 90,
        categoryId: "1",
        chefId: "2",
        rating: 5,
        description: "Класическа българска мусака с картофи, кайма и млечен сос. Любимо ястие на цялото семейство!",
      },
      {
        id: "3",
        name: "Пълнени чушки",
        ingredients: [
          { ingredientId: "10", quantity: 300, unit: "гр." },
          { ingredientId: "11", quantity: 150, unit: "гр." },
          { ingredientId: "3", quantity: 1, unit: "бр." },
          { ingredientId: "1", quantity: 2, unit: "бр." },
          { ingredientId: "5", quantity: 2, unit: "с.л." },
          { ingredientId: "7", quantity: 1, unit: "ч.л." },
        ],
        cookingTime: 60,
        categoryId: "1",
        chefId: "1",
        rating: 4,
        description: "Сочни чушки пълнени с ароматна смес от кайма и ориз. Традиционно българско ястие.",
      },
      {
        id: "4",
        name: "Таратор",
        ingredients: [
          { ingredientId: "2", quantity: 3, unit: "бр." },
          { ingredientId: "14", quantity: 500, unit: "мл" },
          { ingredientId: "5", quantity: 3, unit: "с.л." },
          { ingredientId: "7", quantity: 1, unit: "ч.л." },
        ],
        cookingTime: 10,
        categoryId: "1",
        chefId: "3",
        rating: 4,
        description: "Освежаваща студена супа с краставици и кисело мляко. Идеална за горещите летни дни!",
      },
      {
        id: "5",
        name: "Пържени картофи с яйца",
        ingredients: [
          { ingredientId: "9", quantity: 800, unit: "гр." },
          { ingredientId: "12", quantity: 4, unit: "бр." },
          { ingredientId: "5", quantity: 4, unit: "с.л." },
          { ingredientId: "7", quantity: 1, unit: "ч.л." },
          { ingredientId: "8", quantity: 1, unit: "щипка" },
        ],
        cookingTime: 25,
        categoryId: "1",
        chefId: "2",
        rating: 4,
        description: "Простo и вкусно ястие с пържени картофи и яйца. Бързо решение за обяд или вечеря.",
      },
      {
        id: "6",
        name: "Млечна каша с ориз",
        ingredients: [
          { ingredientId: "11", quantity: 200, unit: "гр." },
          { ingredientId: "15", quantity: 600, unit: "мл" },
          { ingredientId: "7", quantity: 1, unit: "щипка" },
        ],
        cookingTime: 30,
        categoryId: "1",
        chefId: "3",
        rating: 3,
        description: "Кремообразна и питателна каша с ориз и прясно мляко. Отлична за закуска или десерт.",
      },
      {
        id: "7",
        name: "Картофена салата",
        ingredients: [
          { ingredientId: "9", quantity: 600, unit: "гр." },
          { ingredientId: "12", quantity: 3, unit: "бр." },
          { ingredientId: "3", quantity: 1, unit: "бр." },
          { ingredientId: "5", quantity: 3, unit: "с.л." },
          { ingredientId: "6", quantity: 1, unit: "с.л." },
          { ingredientId: "7", quantity: 1, unit: "ч.л." },
        ],
        cookingTime: 35,
        categoryId: "1",
        chefId: "1",
        rating: 4,
        description: "Класическа картофена салата с яйца и лук. Перфектна гарнитура или самостоятелно ястие.",
      },
    ],
    ingredients: [
      { id: "1", name: "Домати", defaultQuantity: 2, defaultUnit: "бр." },
      { id: "2", name: "Краставици", defaultQuantity: 1, defaultUnit: "бр." },
      { id: "3", name: "Лук", defaultQuantity: 1, defaultUnit: "бр." },
      { id: "4", name: "Сирене", defaultQuantity: 200, defaultUnit: "гр." },
      { id: "5", name: "Олио", defaultQuantity: 50, defaultUnit: "мл" },
      { id: "6", name: "Оцет", defaultQuantity: 30, defaultUnit: "мл" },
      { id: "7", name: "Сол", defaultQuantity: 1, defaultUnit: "ч.л." },
      { id: "8", name: "Черен пипер", defaultQuantity: 1, defaultUnit: "щипка" },
      { id: "9", name: "Картофи", defaultQuantity: 500, defaultUnit: "гр." },
      { id: "10", name: "Кайма", defaultQuantity: 300, defaultUnit: "гр." },
      { id: "11", name: "Ориз", defaultQuantity: 200, defaultUnit: "гр." },
      { id: "12", name: "Яйца", defaultQuantity: 2, defaultUnit: "бр." },
      { id: "13", name: "Масло", defaultQuantity: 50, defaultUnit: "гр." },
      { id: "14", name: "Кисело мляко", defaultQuantity: 400, defaultUnit: "мл" },
      { id: "15", name: "Прясно мляко", defaultQuantity: 500, defaultUnit: "мл" },
    ],
    categories: [
      { id: "1", cuisineType: "Българска" },
      { id: "2", cuisineType: "Италианска" },
      { id: "3", cuisineType: "Френска" },
      { id: "4", cuisineType: "Азиатска" },
      { id: "5", cuisineType: "Мексиканска" },
    ],
    chefs: [
      { id: "1", name: "Иван Петров", experience: 10, specialtyRecipes: ["1", "3", "7"] },
      { id: "2", name: "Мария Георгиева", experience: 15, specialtyRecipes: ["2", "5"] },
      { id: "3", name: "Стефан Димитров", experience: 8, specialtyRecipes: ["4", "6"] },
    ],
    ratings: [],
  }
}

export class DatabaseService {
  private static instance: DatabaseService
  private db: Database

  private constructor() {
    this.loadDatabase()
  }

  public static getInstance(): DatabaseService {
    if (!DatabaseService.instance) {
      DatabaseService.instance = new DatabaseService()
    }
    return DatabaseService.instance
  }

  private loadDatabase(): void {
    try {
      if (fs.existsSync(DB_PATH)) {
        const data = fs.readFileSync(DB_PATH, "utf8")
        this.db = JSON.parse(data)
      } else {
        this.db = initDB()
        this.saveDatabase()
      }
    } catch (error) {
      console.error("Грешка при зареждане на базата данни:", error)
      this.db = initDB()
    }
  }

  private saveDatabase(): void {
    try {
      const dir = path.dirname(DB_PATH)
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
      }
      fs.writeFileSync(DB_PATH, JSON.stringify(this.db, null, 2))
    } catch (error) {
      console.error("Грешка при запазване на базата данни:", error)
    }
  }

  public getAll<T>(collection: keyof Database): T[] {
    return this.db[collection] as T[]
  }

  public getById<T extends { id: string }>(collection: keyof Database, id: string): T | undefined {
    return (this.db[collection] as T[]).find((item) => item.id === id)
  }

  public create<T extends { id: string }>(collection: keyof Database, item: T): T {
    const exists = this.getById(collection, item.id)
    if (exists) {
      throw new Error(`Обект с ID ${item.id} вече съществува в ${collection}`)
    }
    ;(this.db[collection] as T[]).push(item)
    this.saveDatabase()
    return item
  }

  public update<T extends { id: string }>(collection: keyof Database, id: string, updates: Partial<T>): T {
    const index = (this.db[collection] as T[]).findIndex((item) => item.id === id)
    if (index === -1) {
      throw new Error(`Обект с ID ${id} не е намерен в ${collection}`)
    }
    ;(this.db[collection] as T[])[index] = { ...(this.db[collection] as T[])[index], ...updates }
    this.saveDatabase()
    return (this.db[collection] as T[])[index]
  }

  public delete(collection: keyof Database, id: string): boolean {
    const index = (this.db[collection] as any[]).findIndex((item) => item.id === id)
    if (index === -1) {
      return false
    }

    this.checkRelationalConstraints(collection, id)
    ;(this.db[collection] as any[]).splice(index, 1)
    this.saveDatabase()
    return true
  }

  private checkRelationalConstraints(collection: keyof Database, id: string): void {
    switch (collection) {
      case "categories":
        const recipesWithCategory = this.db.recipes.filter((r) => r.categoryId === id)
        if (recipesWithCategory.length > 0) {
          throw new Error(`Не може да се изтрие категория с ID ${id} - има свързани рецепти`)
        }
        break
      case "chefs":
        const recipesWithChef = this.db.recipes.filter((r) => r.chefId === id)
        if (recipesWithChef.length > 0) {
          throw new Error(`Не може да се изтрие готвач с ID ${id} - има свързани рецепти`)
        }
        break
      case "ingredients":
        const recipesWithIngredient = this.db.recipes.filter((r) =>
          r.ingredients.some((ing) => ing.ingredientId === id),
        )
        if (recipesWithIngredient.length > 0) {
          throw new Error(`Не може да се изтрие съставка с ID ${id} - използва се в рецепти`)
        }
        break
      case "recipes":
        const ratingsWithRecipe = this.db.ratings.filter((r) => r.recipeId === id)
        if (ratingsWithRecipe.length > 0) {
          this.db.ratings = this.db.ratings.filter((r) => r.recipeId !== id)
        }
        break
    }
  }
}
