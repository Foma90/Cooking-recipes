import express from "express"
import cors from "cors"
import { RecipeService } from "./services/recipeService"
import { IngredientService } from "./services/ingredientService"
import { CategoryService } from "./services/categoryService"
import { ChefService } from "./services/chefService"

const app = express()
const PORT = process.env.PORT || 3001

app.use(cors())
app.use(express.json())

const recipeService = new RecipeService()
const ingredientService = new IngredientService()
const categoryService = new CategoryService()
const chefService = new ChefService()

// Recipe endpoints
app.get("/api/recipes", (req, res) => {
  try {
    const recipes = recipeService.getAllRecipes()
    res.json(recipes)
  } catch (error) {
    res.status(500).json({ error: (error as Error).message })
  }
})

app.get("/api/recipes/:id", (req, res) => {
  try {
    const recipe = recipeService.getRecipeById(req.params.id)
    if (!recipe) {
      return res.status(404).json({ error: "Рецептата не е намерена" })
    }
    res.json(recipe)
  } catch (error) {
    res.status(500).json({ error: (error as Error).message })
  }
})

app.post("/api/recipes", (req, res) => {
  try {
    const recipe = recipeService.createRecipe(req.body)
    res.status(201).json(recipe)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.put("/api/recipes/:id", (req, res) => {
  try {
    const recipe = recipeService.updateRecipe(req.params.id, req.body)
    res.json(recipe)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.delete("/api/recipes/:id", (req, res) => {
  try {
    const deleted = recipeService.deleteRecipe(req.params.id)
    if (!deleted) {
      return res.status(404).json({ error: "Рецептата не е намерена" })
    }
    res.status(204).send()
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

// Ingredient endpoints
app.get("/api/ingredients", (req, res) => {
  try {
    const ingredients = ingredientService.getAllIngredients()
    res.json(ingredients)
  } catch (error) {
    res.status(500).json({ error: (error as Error).message })
  }
})

app.post("/api/ingredients", (req, res) => {
  try {
    const ingredient = ingredientService.createIngredient(req.body)
    res.status(201).json(ingredient)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.put("/api/ingredients/:id", (req, res) => {
  try {
    const ingredient = ingredientService.updateIngredient(req.params.id, req.body)
    res.json(ingredient)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.delete("/api/ingredients/:id", (req, res) => {
  try {
    const deleted = ingredientService.deleteIngredient(req.params.id)
    if (!deleted) {
      return res.status(404).json({ error: "Съставката не е намерена" })
    }
    res.status(204).send()
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

// Category endpoints
app.get("/api/categories", (req, res) => {
  try {
    const categories = categoryService.getAllCategories()
    res.json(categories)
  } catch (error) {
    res.status(500).json({ error: (error as Error).message })
  }
})

app.post("/api/categories", (req, res) => {
  try {
    const category = categoryService.createCategory(req.body)
    res.status(201).json(category)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.put("/api/categories/:id", (req, res) => {
  try {
    const category = categoryService.updateCategory(req.params.id, req.body)
    res.json(category)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.delete("/api/categories/:id", (req, res) => {
  try {
    const deleted = categoryService.deleteCategory(req.params.id)
    if (!deleted) {
      return res.status(404).json({ error: "Категорията не е намерена" })
    }
    res.status(204).send()
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

// Chef endpoints
app.get("/api/chefs", (req, res) => {
  try {
    const chefs = chefService.getAllChefs()
    res.json(chefs)
  } catch (error) {
    res.status(500).json({ error: (error as Error).message })
  }
})

app.post("/api/chefs", (req, res) => {
  try {
    const chef = chefService.createChef(req.body)
    res.status(201).json(chef)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.put("/api/chefs/:id", (req, res) => {
  try {
    const chef = chefService.updateChef(req.params.id, req.body)
    res.json(chef)
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.delete("/api/chefs/:id", (req, res) => {
  try {
    const deleted = chefService.deleteChef(req.params.id)
    if (!deleted) {
      return res.status(404).json({ error: "Готвачът не е намерен" })
    }
    res.status(204).send()
  } catch (error) {
    res.status(400).json({ error: (error as Error).message })
  }
})

app.listen(PORT, () => {
  console.log(`Сървърът работи на порт ${PORT}`)
})
