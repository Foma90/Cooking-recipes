export interface Recipe {
  id: string
  name: string
  ingredients: RecipeIngredient[]
  cookingTime: number
  categoryId: string
  chefId: string
  rating: number
  description: string
}

export interface RecipeIngredient {
  ingredientId: string
  quantity: number
  unit: string
}

export interface Ingredient {
  id: string
  name: string
  defaultQuantity: number
  defaultUnit: string
}

export interface Category {
  id: string
  cuisineType: string
}

export interface Chef {
  id: string
  name: string
  experience: number
  specialtyRecipes: string[]
}

export interface Rating {
  id: string
  recipeId: string
  rating: number
  description: string
}
