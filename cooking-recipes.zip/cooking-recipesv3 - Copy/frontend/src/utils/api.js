const API_BASE_URL = "http://localhost:3001/api"

class ApiService {
  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`
    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Възникна грешка")
    }

    if (response.status === 204) {
      return {}
    }

    return response.json()
  }

  // Recipes
  async getRecipes() {
    return this.request("/recipes")
  }

  async createRecipe(recipe) {
    return this.request("/recipes", {
      method: "POST",
      body: JSON.stringify(recipe),
    })
  }

  async updateRecipe(id, recipe) {
    return this.request(`/recipes/${id}`, {
      method: "PUT",
      body: JSON.stringify(recipe),
    })
  }

  async deleteRecipe(id) {
    return this.request(`/recipes/${id}`, {
      method: "DELETE",
    })
  }

  // Ingredients
  async getIngredients() {
    return this.request("/ingredients")
  }

  async createIngredient(ingredient) {
    return this.request("/ingredients", {
      method: "POST",
      body: JSON.stringify(ingredient),
    })
  }

  async updateIngredient(id, ingredient) {
    return this.request(`/ingredients/${id}`, {
      method: "PUT",
      body: JSON.stringify(ingredient),
    })
  }

  async deleteIngredient(id) {
    return this.request(`/ingredients/${id}`, {
      method: "DELETE",
    })
  }

  // Categories
  async getCategories() {
    return this.request("/categories")
  }

  async createCategory(category) {
    return this.request("/categories", {
      method: "POST",
      body: JSON.stringify(category),
    })
  }

  async updateCategory(id, category) {
    return this.request(`/categories/${id}`, {
      method: "PUT",
      body: JSON.stringify(category),
    })
  }

  async deleteCategory(id) {
    return this.request(`/categories/${id}`, {
      method: "DELETE",
    })
  }

  // Chefs
  async getChefs() {
    return this.request("/chefs")
  }

  async createChef(chef) {
    return this.request("/chefs", {
      method: "POST",
      body: JSON.stringify(chef),
    })
  }

  async updateChef(id, chef) {
    return this.request(`/chefs/${id}`, {
      method: "PUT",
      body: JSON.stringify(chef),
    })
  }

  async deleteChef(id) {
    return this.request(`/chefs/${id}`, {
      method: "DELETE",
    })
  }
}

export const apiService = new ApiService()
