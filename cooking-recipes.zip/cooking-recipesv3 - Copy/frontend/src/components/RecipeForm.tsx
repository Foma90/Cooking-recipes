"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { Recipe, Category, Chef } from "../types"
import { apiService } from "../utils/api"

interface RecipeFormProps {
  recipe?: Recipe
  onSave: () => void
  onCancel: () => void
}

const RecipeForm: React.FC<RecipeFormProps> = ({ recipe, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    name: "",
    ingredients: "",
    cookingTime: 0,
    categoryId: "",
    chefId: "",
  })
  const [categories, setCategories] = useState<Category[]>([])
  const [chefs, setChefs] = useState<Chef[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadSelectData()
    if (recipe) {
      setFormData({
        name: recipe.name,
        ingredients: recipe.ingredients.join(", "),
        cookingTime: recipe.cookingTime,
        categoryId: recipe.categoryId,
        chefId: recipe.chefId,
      })
    }
  }, [recipe])

  const loadSelectData = async () => {
    try {
      const [categoriesData, chefsData] = await Promise.all([apiService.getCategories(), apiService.getChefs()])
      setCategories(categoriesData)
      setChefs(chefsData)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const recipeData = {
        name: formData.name,
        ingredients: formData.ingredients.split(",").map((i) => i.trim()),
        cookingTime: Number(formData.cookingTime),
        categoryId: formData.categoryId,
        chefId: formData.chefId,
      }

      if (recipe) {
        await apiService.updateRecipe(recipe.id, recipeData)
      } else {
        await apiService.createRecipe(recipeData)
      }
      onSave()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">{recipe ? "Редактирай рецепта" : "Добави нова рецепта"}</h2>

      {error && <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Име на рецептата
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label htmlFor="ingredients" className="block text-sm font-medium text-gray-700">
            Съставки (разделени със запетая)
          </label>
          <textarea
            id="ingredients"
            name="ingredients"
            value={formData.ingredients}
            onChange={handleChange}
            required
            rows={3}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label htmlFor="cookingTime" className="block text-sm font-medium text-gray-700">
            Време за готвене (минути)
          </label>
          <input
            type="number"
            id="cookingTime"
            name="cookingTime"
            value={formData.cookingTime}
            onChange={handleChange}
            required
            min="1"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label htmlFor="categoryId" className="block text-sm font-medium text-gray-700">
            Категория
          </label>
          <select
            id="categoryId"
            name="categoryId"
            value={formData.categoryId}
            onChange={handleChange}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Изберете категория</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.cuisineType}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="chefId" className="block text-sm font-medium text-gray-700">
            Готвач
          </label>
          <select
            id="chefId"
            name="chefId"
            value={formData.chefId}
            onChange={handleChange}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Изберете готвач</option>
            {chefs.map((chef) => (
              <option key={chef.id} value={chef.id}>
                {chef.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex space-x-3">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
          >
            {loading ? "Запазване..." : "Запази"}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
          >
            Отказ
          </button>
        </div>
      </form>
    </div>
  )
}

export default RecipeForm
