"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { Recipe, Category, Chef } from "../types"
import { apiService } from "../utils/api"

interface RecipeListProps {
  onEdit: (recipe: Recipe) => void
}

const RecipeList: React.FC<RecipeListProps> = ({ onEdit }) => {
  const [recipes, setRecipes] = useState<Recipe[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [chefs, setChefs] = useState<Chef[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      const [recipesData, categoriesData, chefsData] = await Promise.all([
        apiService.getRecipes(),
        apiService.getCategories(),
        apiService.getChefs(),
      ])
      setRecipes(recipesData)
      setCategories(categoriesData)
      setChefs(chefsData)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете тази рецепта?")) {
      try {
        await apiService.deleteRecipe(id)
        setRecipes(recipes.filter((r) => r.id !== id))
      } catch (err) {
        setError(err instanceof Error ? err.message : "Възникна грешка при изтриване")
      }
    }
  }

  const getCategoryName = (categoryId: string) => {
    const category = categories.find((c) => c.id === categoryId)
    return category ? category.cuisineType : "Неизвестна"
  }

  const getChefName = (chefId: string) => {
    const chef = chefs.find((c) => c.id === chefId)
    return chef ? chef.name : "Неизвестен"
  }

  if (loading) return <div className="text-center">Зареждане...</div>
  if (error) return <div className="text-red-500 text-center">Грешка: {error}</div>

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold mb-4">Рецепти</h2>
      {recipes.length === 0 ? (
        <p className="text-gray-500">Няма добавени рецепти.</p>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {recipes.map((recipe) => (
            <div key={recipe.id} className="border rounded-lg p-4 shadow-sm">
              <h3 className="text-lg font-semibold mb-2">{recipe.name}</h3>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Категория:</strong> {getCategoryName(recipe.categoryId)}
              </p>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Готвач:</strong> {getChefName(recipe.chefId)}
              </p>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Време за готвене:</strong> {recipe.cookingTime} мин.
              </p>
              <p className="text-sm text-gray-600 mb-3">
                <strong>Съставки:</strong> {recipe.ingredients.join(", ")}
              </p>
              <div className="flex space-x-2">
                <button
                  onClick={() => onEdit(recipe)}
                  className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
                >
                  Редактирай
                </button>
                <button
                  onClick={() => handleDelete(recipe.id)}
                  className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
                >
                  Изтрий
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default RecipeList
