"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { Category } from "../types"
import { apiService } from "../utils/api"

const CategoryList: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([])
  const [newCategory, setNewCategory] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingName, setEditingName] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadCategories()
  }, [])

  const loadCategories = async () => {
    try {
      setLoading(true)
      const data = await apiService.getCategories()
      setCategories(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    } finally {
      setLoading(false)
    }
  }

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newCategory.trim()) return

    try {
      const category = await apiService.createCategory({ cuisineType: newCategory })
      setCategories([...categories, category])
      setNewCategory("")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    }
  }

  const handleEdit = async (id: string) => {
    if (!editingName.trim()) return

    try {
      const updated = await apiService.updateCategory(id, { cuisineType: editingName })
      setCategories(categories.map((c) => (c.id === id ? updated : c)))
      setEditingId(null)
      setEditingName("")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    }
  }

  const handleDelete = async (id: string) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете тази категория?")) {
      try {
        await apiService.deleteCategory(id)
        setCategories(categories.filter((c) => c.id !== id))
      } catch (err) {
        setError(err instanceof Error ? err.message : "Възникна грешка при изтриване")
      }
    }
  }

  const startEdit = (category: Category) => {
    setEditingId(category.id)
    setEditingName(category.cuisineType)
  }

  if (loading) return <div className="text-center">Зареждане...</div>

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold mb-4">Категории</h2>

      {error && <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded">{error}</div>}

      <form onSubmit={handleAdd} className="flex space-x-2 mb-4">
        <input
          type="text"
          value={newCategory}
          onChange={(e) => setNewCategory(e.target.value)}
          placeholder="Нова категория..."
          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        />
        <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
          Добави
        </button>
      </form>

      <div className="space-y-2">
        {categories.map((category) => (
          <div key={category.id} className="flex items-center justify-between p-3 border rounded-md">
            {editingId === category.id ? (
              <div className="flex space-x-2 flex-1">
                <input
                  type="text"
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  className="flex-1 px-2 py-1 border border-gray-300 rounded"
                />
                <button
                  onClick={() => handleEdit(category.id)}
                  className="px-3 py-1 bg-green-500 text-white rounded text-sm hover:bg-green-600"
                >
                  Запази
                </button>
                <button
                  onClick={() => setEditingId(null)}
                  className="px-3 py-1 bg-gray-500 text-white rounded text-sm hover:bg-gray-600"
                >
                  Отказ
                </button>
              </div>
            ) : (
              <>
                <span className="font-medium">{category.cuisineType}</span>
                <div className="flex space-x-2">
                  <button
                    onClick={() => startEdit(category)}
                    className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
                  >
                    Редактирай
                  </button>
                  <button
                    onClick={() => handleDelete(category.id)}
                    className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
                  >
                    Изтрий
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default CategoryList
