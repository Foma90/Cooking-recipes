"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { Chef } from "../types"
import { apiService } from "../utils/api"

const ChefList: React.FC = () => {
  const [chefs, setChefs] = useState<Chef[]>([])
  const [showForm, setShowForm] = useState(false)
  const [editingChef, setEditingChef] = useState<Chef | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    experience: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadChefs()
  }, [])

  const loadChefs = async () => {
    try {
      setLoading(true)
      const data = await apiService.getChefs()
      setChefs(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const chefData = {
        name: formData.name,
        experience: Number(formData.experience),
        specialtyRecipes: [],
      }

      if (editingChef) {
        const updated = await apiService.updateChef(editingChef.id, chefData)
        setChefs(chefs.map((c) => (c.id === editingChef.id ? updated : c)))
      } else {
        const newChef = await apiService.createChef(chefData)
        setChefs([...chefs, newChef])
      }

      setFormData({ name: "", experience: 0 })
      setShowForm(false)
      setEditingChef(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Възникна грешка")
    }
  }

  const handleEdit = (chef: Chef) => {
    setEditingChef(chef)
    setFormData({
      name: chef.name,
      experience: chef.experience,
    })
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете този готвач?")) {
      try {
        await apiService.deleteChef(id)
        setChefs(chefs.filter((c) => c.id !== id))
      } catch (err) {
        setError(err instanceof Error ? err.message : "Възникна грешка при изтриване")
      }
    }
  }

  const handleCancel = () => {
    setShowForm(false)
    setEditingChef(null)
    setFormData({ name: "", experience: 0 })
  }

  if (loading) return <div className="text-center">Зареждане...</div>

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Готвачи</h2>
        <button
          onClick={() => setShowForm(true)}
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
        >
          Добави готвач
        </button>
      </div>

      {error && <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded">{error}</div>}

      {showForm && (
        <div className="bg-gray-50 p-4 rounded-md">
          <h3 className="text-lg font-semibold mb-3">{editingChef ? "Редактирай готвач" : "Добави нов готвач"}</h3>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700">Име</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Опит (години)</label>
              <input
                type="number"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: Number(e.target.value) })}
                required
                min="0"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div className="flex space-x-2">
              <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                {editingChef ? "Обнови" : "Добави"}
              </button>
              <button
                type="button"
                onClick={handleCancel}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Отказ
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {chefs.map((chef) => (
          <div key={chef.id} className="border rounded-lg p-4 shadow-sm">
            <h3 className="text-lg font-semibold mb-2">{chef.name}</h3>
            <p className="text-sm text-gray-600 mb-3">
              <strong>Опит:</strong> {chef.experience} години
            </p>
            <div className="flex space-x-2">
              <button
                onClick={() => handleEdit(chef)}
                className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
              >
                Редактирай
              </button>
              <button
                onClick={() => handleDelete(chef.id)}
                className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600"
              >
                Изтрий
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default ChefList
