"use client"

const StarRating = ({ rating, onRatingChange, readonly = false }) => {
  const stars = [1, 2, 3, 4, 5]

  return (
    <div className="star-rating">
      {stars.map((star) => (
        <span
          key={star}
          className={`star ${star <= rating ? "filled" : "empty"}`}
          onClick={!readonly ? () => onRatingChange(star) : undefined}
          style={{ cursor: readonly ? "default" : "pointer" }}
        >
          ★
        </span>
      ))}
      {readonly && <span style={{ marginLeft: "0.5rem", color: "#6b7280" }}>({rating}/5)</span>}
    </div>
  )
}

export default StarRating
