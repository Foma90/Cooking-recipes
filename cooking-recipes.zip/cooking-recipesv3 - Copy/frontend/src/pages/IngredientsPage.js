"use client"

import { useState, useEffect } from "react"
import { apiService } from "../utils/api"

function IngredientsPage() {
  const [ingredients, setIngredients] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editingIngredient, setEditingIngredient] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    defaultQuantity: "",
    defaultUnit: "",
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadIngredients()
  }, [])

  const loadIngredients = async () => {
    try {
      setLoading(true)
      const data = await apiService.getIngredients()
      setIngredients(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      const ingredientData = {
        name: formData.name,
        defaultQuantity: Number.parseFloat(formData.defaultQuantity),
        defaultUnit: formData.defaultUnit,
      }

      if (editingIngredient) {
        await apiService.updateIngredient(editingIngredient.id, ingredientData)
      } else {
        await apiService.createIngredient(ingredientData)
      }

      setFormData({ name: "", defaultQuantity: "", defaultUnit: "" })
      setShowForm(false)
      setEditingIngredient(null)
      loadIngredients()
    } catch (err) {
      setError(err.message)
    }
  }

  const handleEdit = (ingredient) => {
    setEditingIngredient(ingredient)
    setFormData({
      name: ingredient.name,
      defaultQuantity: ingredient.defaultQuantity.toString(),
      defaultUnit: ingredient.defaultUnit,
    })
    setShowForm(true)
  }

  const handleDelete = async (id) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете тази съставка?")) {
      try {
        await apiService.deleteIngredient(id)
        loadIngredients()
      } catch (err) {
        setError(err.message)
      }
    }
  }

  const handleCancel = () => {
    setShowForm(false)
    setEditingIngredient(null)
    setFormData({ name: "", defaultQuantity: "", defaultUnit: "" })
  }

  if (loading) return <div className="loading">Зареждане...</div>

  return (
    <div className="container">
      <div className="flex justify-between items-center">
        <h1 className="page-title">Съставки ({ingredients.length})</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">
          Добави съставка
        </button>
      </div>

      {error && <div className="error">{error}</div>}

      {showForm && (
        <div className="card">
          <h2>{editingIngredient ? "Редактирай съставка" : "Добави нова съставка"}</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Име на съставката</label>
              <input
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Стандартно количество</label>
              <input
                type="number"
                step="0.1"
                className="form-input"
                value={formData.defaultQuantity}
                onChange={(e) => setFormData({ ...formData, defaultQuantity: e.target.value })}
                required
                min="0"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Мерна единица</label>
              <input
                type="text"
                className="form-input"
                value={formData.defaultUnit}
                onChange={(e) => setFormData({ ...formData, defaultUnit: e.target.value })}
                placeholder="напр. гр., мл, бр., ч.л., с.л."
                required
              />
            </div>
            <div className="space-x-2">
              <button type="submit" className="btn btn-primary">
                {editingIngredient ? "Обнови" : "Добави"}
              </button>
              <button type="button" onClick={handleCancel} className="btn btn-secondary">
                Отказ
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md-grid-cols-2 lg-grid-cols-3">
        {ingredients.map((ingredient) => (
          <div key={ingredient.id} className="card">
            <h3>{ingredient.name}</h3>
            <p>
              <strong>Стандартно количество:</strong> {ingredient.defaultQuantity} {ingredient.defaultUnit}
            </p>
            <div className="space-x-2">
              <button onClick={() => handleEdit(ingredient)} className="btn btn-primary">
                Редактирай
              </button>
              <button onClick={() => handleDelete(ingredient.id)} className="btn btn-danger">
                Изтрий
              </button>
            </div>
          </div>
        ))}
      </div>

      {ingredients.length === 0 && !loading && <p className="text-gray-600">Няма добавени съставки.</p>}
    </div>
  )
}

export default IngredientsPage
