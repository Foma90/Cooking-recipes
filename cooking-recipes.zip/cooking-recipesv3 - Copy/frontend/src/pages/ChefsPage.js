"use client"

import { useState, useEffect } from "react"
import { apiService } from "../utils/api"

function ChefsPage() {
  const [chefs, setChefs] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editingChef, setEditingChef] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    experience: "",
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadChefs()
  }, [])

  const loadChefs = async () => {
    try {
      setLoading(true)
      const data = await apiService.getChefs()
      setChefs(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      const chefData = {
        name: formData.name,
        experience: Number.parseInt(formData.experience),
        specialtyRecipes: [],
      }

      if (editingChef) {
        await apiService.updateChef(editingChef.id, chefData)
      } else {
        await apiService.createChef(chefData)
      }

      setFormData({ name: "", experience: "" })
      setShowForm(false)
      setEditingChef(null)
      loadChefs()
    } catch (err) {
      setError(err.message)
    }
  }

  const handleEdit = (chef) => {
    setEditingChef(chef)
    setFormData({
      name: chef.name,
      experience: chef.experience.toString(),
    })
    setShowForm(true)
  }

  const handleDelete = async (id) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете този готвач?")) {
      try {
        await apiService.deleteChef(id)
        loadChefs()
      } catch (err) {
        setError(err.message)
      }
    }
  }

  const handleCancel = () => {
    setShowForm(false)
    setEditingChef(null)
    setFormData({ name: "", experience: "" })
  }

  if (loading) return <div className="loading">Зареждане...</div>

  return (
    <div className="container">
      <div className="flex justify-between items-center">
        <h1 className="page-title">Готвачи ({chefs.length})</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">
          Добави готвач
        </button>
      </div>

      {error && <div className="error">{error}</div>}

      {showForm && (
        <div className="card">
          <h2>{editingChef ? "Редактирай готвач" : "Добави нов готвач"}</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Име</label>
              <input
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Опит (години)</label>
              <input
                type="number"
                className="form-input"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                required
                min="0"
              />
            </div>
            <div className="space-x-2">
              <button type="submit" className="btn btn-primary">
                {editingChef ? "Обнови" : "Добави"}
              </button>
              <button type="button" onClick={handleCancel} className="btn btn-secondary">
                Отказ
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md-grid-cols-2 lg-grid-cols-3">
        {chefs.map((chef) => (
          <div key={chef.id} className="card">
            <h3>{chef.name}</h3>
            <p>
              <strong>Опит:</strong> {chef.experience} години
            </p>
            <div className="space-x-2">
              <button onClick={() => handleEdit(chef)} className="btn btn-primary">
                Редактирай
              </button>
              <button onClick={() => handleDelete(chef.id)} className="btn btn-danger">
                Изтрий
              </button>
            </div>
          </div>
        ))}
      </div>

      {chefs.length === 0 && !loading && <p className="text-gray-600">Няма добавени готвачи.</p>}
    </div>
  )
}

export default ChefsPage
