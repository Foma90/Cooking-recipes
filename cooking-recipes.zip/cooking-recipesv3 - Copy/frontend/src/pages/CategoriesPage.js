"use client"

import { useState, useEffect } from "react"
import { apiService } from "../utils/api"

function CategoriesPage() {
  const [categories, setCategories] = useState([])
  const [newCategory, setNewCategory] = useState("")
  const [editingId, setEditingId] = useState(null)
  const [editingName, setEditingName] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadCategories()
  }, [])

  const loadCategories = async () => {
    try {
      setLoading(true)
      const data = await apiService.getCategories()
      setCategories(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleAdd = async (e) => {
    e.preventDefault()
    if (!newCategory.trim()) return

    try {
      await apiService.createCategory({ cuisineType: newCategory })
      setNewCategory("")
      loadCategories()
    } catch (err) {
      setError(err.message)
    }
  }

  const handleEdit = async (id) => {
    if (!editingName.trim()) return

    try {
      await apiService.updateCategory(id, { cuisineType: editingName })
      setEditingId(null)
      setEditingName("")
      loadCategories()
    } catch (err) {
      setError(err.message)
    }
  }

  const handleDelete = async (id) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете тази категория?")) {
      try {
        await apiService.deleteCategory(id)
        loadCategories()
      } catch (err) {
        setError(err.message)
      }
    }
  }

  const startEdit = (category) => {
    setEditingId(category.id)
    setEditingName(category.cuisineType)
  }

  if (loading) return <div className="loading">Зареждане...</div>

  return (
    <div className="container">
      <h1 className="page-title">Категории ({categories.length})</h1>

      {error && <div className="error">{error}</div>}

      <div className="card">
        <form onSubmit={handleAdd} className="flex space-x-2">
          <input
            type="text"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="Нова категория..."
            className="form-input"
            style={{ flex: 1 }}
          />
          <button type="submit" className="btn btn-primary">
            Добави
          </button>
        </form>
      </div>

      <div className="grid grid-cols-1">
        {categories.map((category) => (
          <div key={category.id} className="card">
            {editingId === category.id ? (
              <div className="flex space-x-2 items-center">
                <input
                  type="text"
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  className="form-input"
                  style={{ flex: 1 }}
                />
                <button onClick={() => handleEdit(category.id)} className="btn btn-success">
                  Запази
                </button>
                <button onClick={() => setEditingId(null)} className="btn btn-secondary">
                  Отказ
                </button>
              </div>
            ) : (
              <div className="flex justify-between items-center">
                <span style={{ fontSize: "1.1rem", fontWeight: "500" }}>{category.cuisineType}</span>
                <div className="space-x-2">
                  <button onClick={() => startEdit(category)} className="btn btn-primary">
                    Редактирай
                  </button>
                  <button onClick={() => handleDelete(category.id)} className="btn btn-danger">
                    Изтрий
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {categories.length === 0 && !loading && <p className="text-gray-600">Няма добавени категории.</p>}
    </div>
  )
}

export default CategoriesPage
