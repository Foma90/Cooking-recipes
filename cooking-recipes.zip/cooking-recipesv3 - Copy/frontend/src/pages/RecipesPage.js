"use client"

import { useState, useEffect } from "react"
import { apiService } from "../utils/api"
import StarRating from "../components/StarRating"

function RecipesPage() {
  const [recipes, setRecipes] = useState([])
  const [categories, setCategories] = useState([])
  const [chefs, setChefs] = useState([])
  const [ingredients, setIngredients] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editingRecipe, setEditingRecipe] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    cookingTime: "",
    categoryId: "",
    chefId: "",
    rating: 5,
    ingredients: [],
  })

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      const [recipesData, categoriesData, chefsData, ingredientsData] = await Promise.all([
        apiService.getRecipes(),
        apiService.getCategories(),
        apiService.getChefs(),
        apiService.getIngredients(),
      ])
      setRecipes(recipesData)
      setCategories(categoriesData)
      setChefs(chefsData)
      setIngredients(ingredientsData)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const recipeData = {
        name: formData.name,
        description: formData.description,
        ingredients: formData.ingredients,
        cookingTime: Number.parseInt(formData.cookingTime),
        categoryId: formData.categoryId,
        chefId: formData.chefId,
        rating: formData.rating,
      }

      if (editingRecipe) {
        await apiService.updateRecipe(editingRecipe.id, recipeData)
      } else {
        await apiService.createRecipe(recipeData)
      }

      resetForm()
      loadData()
    } catch (err) {
      setError(err.message)
    }
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      cookingTime: "",
      categoryId: "",
      chefId: "",
      rating: 5,
      ingredients: [],
    })
    setShowForm(false)
    setEditingRecipe(null)
  }

  const handleEdit = (recipe) => {
    setEditingRecipe(recipe)
    setFormData({
      name: recipe.name,
      description: recipe.description,
      cookingTime: recipe.cookingTime.toString(),
      categoryId: recipe.categoryId,
      chefId: recipe.chefId,
      rating: recipe.rating,
      ingredients: recipe.ingredients,
    })
    setShowForm(true)
  }

  const handleDelete = async (id) => {
    if (window.confirm("Сигурни ли сте, че искате да изтриете тази рецепта?")) {
      try {
        await apiService.deleteRecipe(id)
        loadData()
      } catch (err) {
        setError(err.message)
      }
    }
  }

  const addIngredient = () => {
    setFormData({
      ...formData,
      ingredients: [...formData.ingredients, { ingredientId: "", quantity: 1, unit: "" }],
    })
  }

  const updateIngredient = (index, field, value) => {
    const newIngredients = [...formData.ingredients]
    newIngredients[index][field] = field === "quantity" ? Number.parseFloat(value) || 0 : value
    setFormData({ ...formData, ingredients: newIngredients })
  }

  const removeIngredient = (index) => {
    const newIngredients = formData.ingredients.filter((_, i) => i !== index)
    setFormData({ ...formData, ingredients: newIngredients })
  }

  const getCategoryName = (categoryId) => {
    const category = categories.find((c) => c.id === categoryId)
    return category ? category.cuisineType : "Неизвестна"
  }

  const getChefName = (chefId) => {
    const chef = chefs.find((c) => c.id === chefId)
    return chef ? chef.name : "Неизвестен"
  }

  const getIngredientName = (ingredientId) => {
    const ingredient = ingredients.find((i) => i.id === ingredientId)
    return ingredient ? ingredient.name : "Неизвестна"
  }

  if (loading) return <div className="loading">Зареждане...</div>

  return (
    <div className="container">
      <div className="flex justify-between items-center">
        <h1 className="page-title">Рецепти ({recipes.length})</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">
          Добави рецепта
        </button>
      </div>

      {error && <div className="error">{error}</div>}

      {showForm && (
        <div className="card">
          <h2>{editingRecipe ? "Редактирай рецепта" : "Добави нова рецепта"}</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Име на рецептата</label>
              <input
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Описание</label>
              <textarea
                className="form-input"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows="3"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Време за готвене (минути)</label>
              <input
                type="number"
                className="form-input"
                value={formData.cookingTime}
                onChange={(e) => setFormData({ ...formData, cookingTime: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Категория</label>
              <select
                className="form-input"
                value={formData.categoryId}
                onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                required
              >
                <option value="">Изберете категория</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.cuisineType}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Готвач</label>
              <select
                className="form-input"
                value={formData.chefId}
                onChange={(e) => setFormData({ ...formData, chefId: e.target.value })}
                required
              >
                <option value="">Изберете готвач</option>
                {chefs.map((chef) => (
                  <option key={chef.id} value={chef.id}>
                    {chef.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Оценка</label>
              <StarRating rating={formData.rating} onRatingChange={(rating) => setFormData({ ...formData, rating })} />
            </div>

            <div className="form-group">
              <label className="form-label">Съставки</label>
              <div className="ingredients-list">
                {formData.ingredients.map((ingredient, index) => (
                  <div key={index} className="ingredient-item">
                    <select
                      value={ingredient.ingredientId}
                      onChange={(e) => updateIngredient(index, "ingredientId", e.target.value)}
                      required
                    >
                      <option value="">Изберете съставка</option>
                      {ingredients.map((ing) => (
                        <option key={ing.id} value={ing.id}>
                          {ing.name}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="Количество"
                      value={ingredient.quantity}
                      onChange={(e) => updateIngredient(index, "quantity", e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      placeholder="Единица"
                      value={ingredient.unit}
                      onChange={(e) => updateIngredient(index, "unit", e.target.value)}
                      required
                    />
                    <button type="button" onClick={() => removeIngredient(index)} className="btn btn-danger btn-small">
                      Премахни
                    </button>
                  </div>
                ))}
                <button type="button" onClick={addIngredient} className="btn btn-secondary btn-small">
                  Добави съставка
                </button>
              </div>
            </div>

            <div className="space-x-2">
              <button type="submit" className="btn btn-primary">
                {editingRecipe ? "Обнови" : "Добави"}
              </button>
              <button type="button" onClick={resetForm} className="btn btn-secondary">
                Отказ
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md-grid-cols-2 lg-grid-cols-3">
        {recipes.map((recipe) => (
          <div key={recipe.id} className="card">
            <h3>{recipe.name}</h3>
            <StarRating rating={recipe.rating} readonly />
            <p style={{ marginTop: "0.5rem" }}>
              <strong>Категория:</strong> {getCategoryName(recipe.categoryId)}
            </p>
            <p>
              <strong>Готвач:</strong> {getChefName(recipe.chefId)}
            </p>
            <p>
              <strong>Време за готвене:</strong> {recipe.cookingTime} мин.
            </p>
            <p>
              <strong>Описание:</strong> {recipe.description}
            </p>
            <div style={{ marginTop: "1rem" }}>
              <strong>Съставки:</strong>
              <ul style={{ textAlign: "left", marginTop: "0.5rem" }}>
                {recipe.ingredients.map((ing, index) => (
                  <li key={index}>
                    {getIngredientName(ing.ingredientId)} - {ing.quantity} {ing.unit}
                  </li>
                ))}
              </ul>
            </div>
            <div className="space-x-2" style={{ marginTop: "1rem" }}>
              <button onClick={() => handleEdit(recipe)} className="btn btn-primary">
                Редактирай
              </button>
              <button onClick={() => handleDelete(recipe.id)} className="btn btn-danger">
                Изтрий
              </button>
            </div>
          </div>
        ))}
      </div>

      {recipes.length === 0 && !loading && <p className="text-gray-600">Няма добавени рецепти.</p>}
    </div>
  )
}

export default RecipesPage
