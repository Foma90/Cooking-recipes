export interface Recipe {
  id: string
  name: string
  ingredients: string[]
  cookingTime: number
  categoryId: string
  chefId: string
}

export interface Ingredient {
  id: string
  name: string
  quantity: number
  unit: string
}

export interface Category {
  id: string
  cuisineType: string
}

export interface Chef {
  id: string
  name: string
  experience: number
  specialtyRecipes: string[]
}

export interface Rating {
  id: string
  recipeId: string
  rating: number
  description: string
}
