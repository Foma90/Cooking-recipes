"use client"

import { useState } from "react"
import "./App.css"
import RecipesPage from "./pages/RecipesPage"
import CategoriesPage from "./pages/CategoriesPage"
import ChefsPage from "./pages/ChefsPage"
import IngredientsPage from "./pages/IngredientsPage"

function App() {
  const [currentPage, setCurrentPage] = useState("recipes")

  const renderPage = () => {
    switch (currentPage) {
      case "recipes":
        return <RecipesPage />
      case "categories":
        return <CategoriesPage />
      case "chefs":
        return <ChefsPage />
      case "ingredients":
        return <IngredientsPage />
      default:
        return <RecipesPage />
    }
  }

  return (
    <div className="App">
      <nav className="navbar">
        <div className="nav-container">
          <div className="nav-buttons">
            <button
              onClick={() => setCurrentPage("recipes")}
              className={`nav-button ${currentPage === "recipes" ? "active" : ""}`}
            >
              Рецепти
            </button>
            <button
              onClick={() => setCurrentPage("categories")}
              className={`nav-button ${currentPage === "categories" ? "active" : ""}`}
            >
              Категории
            </button>
            <button
              onClick={() => setCurrentPage("chefs")}
              className={`nav-button ${currentPage === "chefs" ? "active" : ""}`}
            >
              Готвачи
            </button>
            <button
              onClick={() => setCurrentPage("ingredients")}
              className={`nav-button ${currentPage === "ingredients" ? "active" : ""}`}
            >
              Съставки
            </button>
          </div>
        </div>
      </nav>

      <main className="main-content">{renderPage()}</main>
    </div>
  )
}

export default App
